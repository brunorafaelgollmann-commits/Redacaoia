exports.handler = async function (event) {
  try {
    const { texto } = JSON.parse(event.body);

    if (!texto) {
      return {
        statusCode: 400,
        body: JSON.stringify({ erro: "Texto vazio" }),
      };
    }

    const response = await fetch(
      "https://api-inference.huggingface.co/models/google/flan-t5-large",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.HF_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: `Corrija a redação abaixo como um professor do ENEM e dê um feedback:\n\n${texto}`,
          options: { wait_for_model: true },
        }),
      }
    );

    const data = await response.json();

    if (data.error) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          erro: "Erro da IA",
          detalhe: data.error,
        }),
      };
    }

    const resposta = data[0]?.generated_text || "Sem resposta da IA";

    // 🔥 GERA NOTA AUTOMÁTICA (baseada no tamanho do texto)
    let nota = 0;

    if (texto.length > 300) nota += 200;
    if (texto.length > 600) nota += 200;
    if (texto.length > 900) nota += 200;
    if (texto.includes(".")) nota += 200;
    if (texto.split(" ").length > 100) nota += 200;

    // Limita a 1000
    if (nota > 1000) nota = 1000;

    return {
      statusCode: 200,
      body: JSON.stringify({
        nota: nota,
        feedback: resposta,
      }),
    };

  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        erro: "Erro geral",
        detalhe: e.message,
      }),
    };
  }
};